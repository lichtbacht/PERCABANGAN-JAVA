package com.mycompany.ifthenelse;
 
public class IfThenElse {
    public static void main(String[] args) {
        boolean isOn = false;


        if (isOn) {
            System.out.println("Menyalakan lampu");
        } else {
            System.out.println("Kondisi tidak terpenuhi...");
        }
    }
}
